package Hilo;

import application.IndexController;
import javafx.util.Duration;
import modelo.Entrenadores;

public class HiloPuntuacion extends Thread {

	private IndexController index;
	private Entrenadores jugador;
	
	public HiloPuntuacion(IndexController index, Entrenadores jugador) {
		this.index = index;
		this.jugador = jugador;
	}
	
	public void run() {
		boolean control = index.getControl();
		while(control) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			jugador.setPuntaje(jugador.getPuntaje()+2);
		}
		
	}
}

package modelo;

public class Pokemon {
	
	private String nombre;
	private String tipo;
	private int posX;
	private int posY;
		
	public Pokemon(String nombre, String tipo, int posX, int posY) {
		this.nombre = nombre;
		this.tipo = tipo;
		this.posX = posX;
		this.posY = posY;
	}
	

	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getTipo() {
		return tipo;
	}


	public void setTipo(String tipo) {
		this.tipo = tipo;
	}


	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}
	
	
	
	
	
	
}

package modelo;

import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;


public class Entrenadores implements Serializable {
	
	private String Nombre;
	private int puntaje;

	public Entrenadores(String nombre, int puntaje) {
		Nombre = nombre;
		this.puntaje = puntaje;
	
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public int getPuntaje() {
		return puntaje;
	}

	public void setPuntaje(int puntaje) {
		this.puntaje = puntaje;
	}

	public void serializar(Entrenadores a) {
		try {			
			File file = new File ("archivos/entrenadores.ser"); 
			FileOutputStream fileOutS = new FileOutputStream(file);
			ObjectOutputStream salida = new ObjectOutputStream(fileOutS);
			salida.writeObject(a);
			salida.getClass();
		}catch(FileNotFoundException e){
			System.out.println(e.getMessage());
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}
	
}

package modelo;

import java.io.*;
import java.util.ArrayList;

public class Gimnasio {
	
	private ArrayList<Pokemon> pokemon;
	private ArrayList<Entrenadores> entrenador;
	
	public Gimnasio() {
		pokemon = new ArrayList<Pokemon>();
	}
	
	public void add(Pokemon a) {
		pokemon.add(a);
	}
	
	public Pokemon dar(int a) {
		return pokemon.get(a);
	}

	public ArrayList<Pokemon> getPokemon() {
		return pokemon;
	}

	public void setPokemon(ArrayList<Pokemon> pokemon) {
		this.pokemon = pokemon;
	}
		
	public ArrayList<Entrenadores> getEntrenadores(){
		return entrenador;
	}
	
	public void guardar(Entrenadores e) throws IOException {
		File archivo = new File ("archivos/textoPlano.txt");
		FileWriter fr = new FileWriter(archivo);
		BufferedWriter br = new BufferedWriter(fr);
		String linea = e.getNombre()+"-"+Integer.valueOf(e.getPuntaje())+"\n";
		br.write(linea);
		entrenador.add(e);
		br.close();
	}
}

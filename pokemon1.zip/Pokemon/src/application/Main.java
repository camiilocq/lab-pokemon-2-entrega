package application;
	
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import modelo.Entrenadores;
import modelo.Gimnasio;
import modelo.Pokemon;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;


public class Main extends Application {
	
	private static Gimnasio gim;
	private static Stage primaryStage;
	private static Stage entrenarStage;
	private static Stage guardarStage;
	private static Stage atraparStage;
	private static GuardarController guardar;
	
	private  static ArrayList<Entrenadores> entrenador;
	

	
	public Main() {
		primaryStage = new Stage();
		entrenarStage = new Stage();
		guardarStage = new Stage();
		atraparStage = new Stage();
		entrenador = new ArrayList<Entrenadores>();
		try {
			recordar();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void recordar() throws IOException{
		String nombre = "";
		int punta = 0;
		File archivo = new File ("archivos/textoPlano");
		FileReader fr = new FileReader(archivo);
		BufferedReader br = new BufferedReader(fr);
		String line = br.readLine();
		while(line!=null) {
			String[] string = line.split("-");
			nombre = string[0];
			punta = Integer.parseInt(string[1]);
			entrenador.add(new Entrenadores(nombre, punta));
		}
		br.close();
	}

	public static ArrayList<Entrenadores> getEntrenador() {
		return entrenador;
	}

	public void setEntrenador(ArrayList<Entrenadores> entrenador) {
		this.entrenador = entrenador;
	}

	public static void guardar(Entrenadores e)throws IOException {
		gim.guardar(e);
	}
	
	public static void ad(Entrenadores e) {
		entrenador.add(e);
	}
	
	@Override
	public void start(Stage primaryStage) {
			this.primaryStage = primaryStage;
		try {
			Pane root = (Pane)FXMLLoader.load(getClass().getResource("Inicio.fxml"));
			Scene scene = new Scene(root,561,440);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("POKEMON");
			this.primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	

	public Gimnasio getGimnasio() {
		return gim;
	}
	


	public static void darAtrapar() throws IOException {
		FXMLLoader loader =  new FXMLLoader();
		loader.setLocation(Main.class.getResource("Index.fxml"));
		AnchorPane atrapar = loader.load();
		
		atraparStage.setTitle("POKEM�N");
		atraparStage.initOwner(primaryStage);
		
		Scene scene = new Scene(atrapar,500,499);
		atraparStage.setScene(scene);	
		primaryStage.close();
		atraparStage.showAndWait();	
		
		
	}


	public static void darEntrenar() throws IOException {
		FXMLLoader loader =  new FXMLLoader();
		loader.setLocation(Main.class.getResource("Entrenar.fxml"));
		AnchorPane entrenar = loader.load();
		
		entrenarStage.setTitle("POKEM�N");
		entrenarStage.initOwner(primaryStage);
		
		Scene scene = new Scene(entrenar, 486, 500);
		entrenarStage.setScene(scene);	
		primaryStage.close();
		entrenarStage.showAndWait();
		
	}
	
	public static void guardar() throws IOException {
		FXMLLoader loader =  new FXMLLoader();
		loader.setLocation(Main.class.getResource("Guardar.fxml"));
		AnchorPane guardar = loader.load();
		
		guardarStage.setTitle("POKEM�N");
		guardarStage.initOwner(primaryStage);
		
		Scene scene = new Scene(guardar, 599, 374);
		guardarStage.setScene(scene);
		atraparStage.close();
		guardarStage.showAndWait();	
		
	}
	
	public static GuardarController darClaseGuardar() {
		return guardar;
	}

	
}

package application;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import modelo.Entrenadores;

public class InicioController {
	
	@FXML private Button atrapar;
	@FXML private Button entrenar;
	@FXML private TextField nombre;
	
	private static Main main;
	
	public InicioController() {
		
	}
	
	public void atrapar() {
		try {
				if(nombre.getText().equals("")) {
					nombre.setText("DEFAULT");
				}
				Entrenadores entrenador = new Entrenadores(nombre.getText(), 0);
				main.ad(entrenador);
				main.darAtrapar();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
		
	
	public void entrenar() {
		try {
			if(nombre.getText().equals("")) {
				nombre.setText("DEFAULT");
			}
			Entrenadores entrenador = new Entrenadores(nombre.getText(), 0);
			main.ad(entrenador);
			main.darEntrenar();
		} catch (IOException e) {
			e.printStackTrace();
		}catch (IllegalStateException a ) {
			System.out.println(a.getMessage());
		}
	}
	
}

package application;

import java.io.IOException;
import java.security.SecureRandom;

import Hilo.HiloPuntuacion;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.util.Duration;
import modelo.Entrenadores;
import modelo.Pokemon;

public class IndexController {
	
	private static Main main2;
	
	
	@FXML private ImageView pikachuP;
	@FXML private ImageView tentacruelP;
	@FXML private ImageView lugiaP;
	@FXML private ImageView bandera;
	@FXML private ImageView tentacruel;
	@FXML private ImageView pikachu;
	@FXML private ImageView lugia;
	@FXML private ImageView pokebola;
	@FXML private Label lab;
	@FXML private Boolean control;
	
	private Pokemon po;
	private Pokemon po2;
	private Pokemon po3;
	
	private GuardarController g;
	private HiloPuntuacion hilo;

	
	public void initialize() {
		
		control = true;
		SecureRandom random = new SecureRandom();
		pokebola.setVisible(false);
		tentacruelP.setVisible(false);
		pikachuP.setVisible(false);
		lugiaP.setVisible(false);
			
			
			Entrenadores a = main2.getEntrenador().get(main2.getEntrenador().size()-1);
			hilo = new HiloPuntuacion(this, a);
			po = new Pokemon("TENTACRUEL", "ACUATICO",397,338);
			po2 = new Pokemon("PIKACHU","ELECTRICO",397,338);
			po3 = new Pokemon("LUGIA","PS�QUICO",416,404);
			
		Timeline timeLineAnimation = new Timeline(new KeyFrame(Duration.millis(30), new EventHandler<ActionEvent>() {
			int dx1 = 1 + random.nextInt(7);
			int dx2 = 1 + random.nextInt(7);
			int dx3 = 1 + random.nextInt(7);
		
			@Override
			public void handle(ActionEvent e) {
			
			po.setPosX(po.getPosX() - dx1);
			pikachuP.setLayoutX(po.getPosX() - dx1);
			
			po2.setPosX(po2.getPosX() - dx2);
			tentacruelP.setLayoutX(po2.getPosX() - dx2);
			
			po3.setPosX(po3.getPosX() - dx3);
			lugiaP.setLayoutX(po3.getPosX() - dx3);
			
			if(po.getPosX()<10) {
				po.setPosX(397);
			}else if(po2.getPosX()<10) {
				po2.setPosX(378);
			}else if(po3.getPosX()<10){
				po3.setPosX(416);
			}
				lab.setText(Integer.toString(a.getPuntaje()));
			}
			
				
		}));

		timeLineAnimation.setCycleCount(Timeline.INDEFINITE);
		
		tentacruelP.setOnMouseClicked(new EventHandler<MouseEvent>() {

		@Override
			public void handle(MouseEvent event) {
			if(tentacruelP.getLayoutX()>bandera.getLayoutX()) {
				timeLineAnimation.stop();
				double distancia = 378-tentacruelP.getLayoutX();
				tentacruelP.setVisible(false);
				pokebola.setLayoutX(tentacruelP.getLayoutX());
				pokebola.setLayoutY(tentacruelP.getLayoutY());
				pokebola.setVisible(true);
				mostrarMensaje(po.getNombre(),po.getTipo(), distancia);
				control = false;
			}else if(tentacruelP.getLayoutX()<bandera.getLayoutX()) {
				String nombre = main2.getEntrenador().get(main2.getEntrenador().size()-1).getNombre();
				Alert aler = new Alert(AlertType.INFORMATION,nombre+" NO ATRAPASTE AL POKEMON, PASO LA BANDERA", ButtonType.OK, ButtonType.CANCEL);
				aler.showAndWait();
			}
			try {
				main2.guardar(a);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		});
		
		pikachuP.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
				public void handle(MouseEvent event) {
				if(pikachuP.getLayoutX()>bandera.getLayoutX()) {
					timeLineAnimation.stop();
					double distancia = 397-pikachuP.getLayoutX();
					pikachuP.setVisible(false);
					pokebola.setLayoutX(pikachuP.getLayoutX());
					pokebola.setLayoutY(pikachuP.getLayoutY());
					pokebola.setVisible(true);
					mostrarMensaje(po2.getNombre(),po2.getTipo(), distancia);
				}else if(pikachuP.getLayoutX()<bandera.getLayoutX()) {
					String nombre = main2.getEntrenador().get(main2.getEntrenador().size()-1).getNombre();
					Alert aler = new Alert(AlertType.INFORMATION,nombre+" NO ATRAPASTE AL POKEMON, PASO LA BANDERA", ButtonType.OK, ButtonType.CANCEL);
					aler.showAndWait();
				}
				try {
					main2.guardar(a);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			});
		
		lugiaP.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
				public void handle(MouseEvent event) {
				if(lugiaP.getLayoutX()>bandera.getLayoutX()) {
					timeLineAnimation.stop();
					double distancia = 416-lugiaP.getLayoutX();
					lugiaP.setVisible(false);
					pokebola.setLayoutX(lugiaP.getLayoutX());
					pokebola.setLayoutY(lugiaP.getLayoutY());
					pokebola.setVisible(true);
					mostrarMensaje(po3.getNombre(),po3.getTipo(), distancia);
				}else if(lugiaP.getLayoutX()<bandera.getLayoutX()) {
					String nombre = main2.getEntrenador().get(main2.getEntrenador().size()-1).getNombre();
					Alert aler = new Alert(AlertType.INFORMATION,nombre+" NO ATRAPASTE AL POKEMON, PASO LA BANDERA", ButtonType.OK, ButtonType.CANCEL);
					aler.showAndWait();
				}
				try {
					main2.guardar(a);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
			});
		
		tentacruel.setOnMouseClicked(new EventHandler<MouseEvent>() {
	
			@Override
				public void handle(MouseEvent event) {
				tentacruelP.setVisible(true);
				timeLineAnimation.play();
				if(timeLineAnimation.getStatus().equals(Animation.Status.RUNNING)){
					tentacruel.setVisible(false);
					pikachu.setVisible(false);
					lugia.setVisible(false);
				}
				hilo.start();
			}
		});
		
		pikachu.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
				public void handle(MouseEvent event) {
				pikachuP.setVisible(true);
				timeLineAnimation.play();
				if(timeLineAnimation.getStatus().equals(Animation.Status.RUNNING)){
					tentacruel.setVisible(false);
					pikachu.setVisible(false);
					lugia.setVisible(false);
				}
				hilo.start();
			}
		});
		
		lugia.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
				public void handle(MouseEvent event) {
				lugiaP.setVisible(true);
				timeLineAnimation.play();
				if(timeLineAnimation.getStatus().equals(Animation.Status.RUNNING)){
					tentacruel.setVisible(false);
					pikachu.setVisible(false);
					lugia.setVisible(false);
				}
				hilo.start();
			}
		});
	}
	
	
	public Label getLabel() {
		return lab;
	}
	
	public Boolean getControl() {
		return control;
	}
	public void mostrarMensaje(String string, String tipo, double distancia) {
		String nombre = main2.getEntrenador().get(main2.getEntrenador().size()-1).getNombre();
		Alert alert = new Alert(AlertType.INFORMATION, nombre+" el pokemon: "+string +" de tipo: "+tipo+" recorrio: "+distancia+" metro de distancia", ButtonType.OK, ButtonType.CANCEL);
		alert.showAndWait();	
		try {
			main2.guardar();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
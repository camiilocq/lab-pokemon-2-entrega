package application;


import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import modelo.Entrenadores;

public class GuardarController {
	
	
	@FXML private ListView<Entrenadores> lista;
	@FXML private ObservableList<Entrenadores> dataLista = FXCollections.observableArrayList();
	@FXML private Button alfabetico;
	@FXML private Button puntaje;
	@FXML private Button inicio; 
	
	private static Main main3;
	private Entrenadores entrenador;
	
	public void initialize(){
		
	}

	public void serializar(Entrenadores a) {
		entrenador.serializar(a);
	}
	
	public void deserializar(){
		int control = 0;
		try {
		FileInputStream fis = new FileInputStream("archivos/entrenadores.ser");
        ObjectInputStream ois = new ObjectInputStream(fis);
        while(control<3) {
        Entrenadores obj2 = (Entrenadores)ois.readObject();
        dataLista.add(control, obj2);
        control++;
        }
        ois.close();
        fis.close();
	    }catch(IOException ioe){
	    	ioe.printStackTrace();
	    }catch(ClassNotFoundException cnfe){
	        cnfe.printStackTrace();
	    }
		
	}
	
	
}

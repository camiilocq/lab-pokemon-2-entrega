package application;

import java.io.IOException;
import java.security.SecureRandom;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.util.Duration;
import modelo.Pokemon;

public class EntrenarController {
	
	private static Main main1;
	
	@FXML private ImageView ball1;
	@FXML private ImageView ball2;
	@FXML private ImageView ball3;
	@FXML private ImageView ball4;
	@FXML private ImageView poke1;
	@FXML private ImageView poke2;
	@FXML private ImageView poke3;
	
	private Pokemon po1;
	private Pokemon po2;
	private Pokemon po3;
	
	
	
	public void initialize() {
		ball4.setVisible(false);
		SecureRandom random = new SecureRandom();
		poke1.setVisible(false);
		poke2.setVisible(false);
		poke3.setVisible(false);
		po1 = new Pokemon("TENTACRUEL","ACUATICO",363, 285);
		po2 = new Pokemon("PIKACHU","ELECTRICO",376,332);
		po3 = new Pokemon("LUGIA","PSIQU�CO",398,394);
		Timeline timeLineAnimation = new Timeline(new KeyFrame(Duration.millis(30), new EventHandler<ActionEvent>() {
			
			int dx1 = 1 + random.nextInt(7);
			int dx2 = 1 + random.nextInt(7);
			int dx3 = 1 + random.nextInt(7);
			
				@Override
				public void handle(ActionEvent e) {
				po1.setPosX(po1.getPosX() - dx1);
				po2.setPosX(po2.getPosX() - dx2);
				po3.setPosX(po3.getPosX() - dx3);
				poke1.setLayoutX(po1.getPosX() - dx1);
				poke2.setLayoutX(po2.getPosX() - dx2);
				poke3.setLayoutX(po3.getPosX() - dx3);
				
				if(po1.getPosX()<10) {
					po1.setPosX(363);
				}else if(po2.getPosX()<10) {
					po2.setPosX(376);
				}else if(po3.getPosX()<10) {
					po3.setPosX(398);
				}
				}
			}));

			timeLineAnimation.setCycleCount(Timeline.INDEFINITE);
		
			
			
			ball1.setOnMouseClicked(new EventHandler<MouseEvent>() {

				@Override
					public void handle(MouseEvent event) {
						poke1.setVisible(true);
						timeLineAnimation.play();
			}
			});	
			

			ball2.setOnMouseClicked(new EventHandler<MouseEvent>() {

				@Override
					public void handle(MouseEvent event) {
						poke2.setVisible(true);
						timeLineAnimation.play();
			}
			});	
			

			ball3.setOnMouseClicked(new EventHandler<MouseEvent>() {

				@Override
					public void handle(MouseEvent event) {
						poke3.setVisible(true);
						timeLineAnimation.play();
			}
			});	
			
			poke1.setOnMouseClicked(new EventHandler<MouseEvent>() {

				@Override
				public void handle(MouseEvent event) {
					timeLineAnimation.stop();
					poke1.setVisible(false);
					ball4.setLayoutX(po1.getPosX());
					ball4.setLayoutY(po1.getPosY());
					ball4.setVisible(true);
					mostrarMensaje("TENTACRUEL");
				}
			});
			
			poke2.setOnMouseClicked(new EventHandler<MouseEvent>() {

				@Override
				public void handle(MouseEvent event) {
					timeLineAnimation.stop();
					poke2.setVisible(false);
					ball4.setLayoutX(po2.getPosX());
					ball4.setLayoutY(po2.getPosY());
					ball4.setVisible(true);
					mostrarMensaje("LUGIA");
				}
			});
			
			poke3.setOnMouseClicked(new EventHandler<MouseEvent>() {

				@Override
				public void handle(MouseEvent event) {
					timeLineAnimation.stop();
					poke3.setVisible(false);
					ball4.setLayoutX(po3.getPosX());
					ball4.setLayoutY(po3.getPosY());
					ball4.setVisible(true);
					mostrarMensaje("TOTODILE");
				}
			});
			
	}
	
	public void mostrarMensaje(String mensaje) {
		Alert alert = new Alert(AlertType.INFORMATION,"�FELICIDADES ATRAPASTE AL POKEMON: "+mensaje+"!", ButtonType.OK, ButtonType.CANCEL);
		alert.showAndWait();
		
		
		
	}
	

}
